<!-- Footer Start -->
<footer class="footer">
	<center>
	Copyright&copy; 2017 BNS SHAHEED MOAZZAM TRAINING SCHOOL MANAGEMENT SYSTEM. All rights reserved.</center>
</footer>
<!-- Footer Ends -->



</section>



<!-- js placed at the end of the document so the pages load faster -->
  	{!! Html::script('js/jquery.js') !!}
  	{!! Html::script('js/bootstrap.min.js') !!}
  	{!! Html::script('js/bootstrap-confirmation.min.js') !!}
  	{!! Html::script('js/pace.min.js')!!}
  	{!! Html::script('js/wow.min.js') !!}
  	{!! Html::script('js/jquery.nicescroll.js') !!}
  	{!! Html::script('js/jquery.app.js') !!}

     @yield('script')
