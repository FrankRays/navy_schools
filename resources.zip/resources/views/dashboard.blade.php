@extends('layouts.default')
    @section('content')
        @include('includes.alert')
        <h1>This is the TC home page. This page is under construction</h1>
@stop